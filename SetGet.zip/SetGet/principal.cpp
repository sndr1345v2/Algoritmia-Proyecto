#include "principal.h"

principal::principal(QObject *parent) : QObject(parent)
{

}
