#include <QCoreApplication>
#include <QDebug>

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);
    return a.exec();

    qDebug()<<"Hola que hace";
}
